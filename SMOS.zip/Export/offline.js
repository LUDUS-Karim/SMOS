﻿{
	"version": 1656088294,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/worldmap_1-sheet0.png",
		"images/sprite-sheet0.png",
		"images/map_bg.png",
		"images/satellite-sheet0.png",
		"images/country-sheet0.png",
		"images/country-sheet1.png",
		"images/panel-sheet0.png",
		"images/countrynamebg-sheet0.png",
		"images/requestcontainer-sheet0.png",
		"images/validationbutton-sheet0.png",
		"images/answerimage-sheet0.png",
		"images/countrydisplay-sheet0.png",
		"images/laser-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}